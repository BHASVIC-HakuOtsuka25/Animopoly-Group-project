import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BigAnt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BigAnt extends Animals
{
    /**
     * Act - do whatever the BigAnt wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public BigAnt(){
        super(0,700,false,70);
    }
    public void act()
    {
        // Add your action code here.
    }
}
