import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cards here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Animals extends Actor
{
    /**
     * Act - do whatever the Cards wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int cost;
    int stopCost;
    int level;
    int money;
    int ownedBy;
    int upgradeCost;
    boolean owned;
    boolean upgradeClicked=true;
    boolean buyClicked=true;
    Board board;
    public Animals(int Level, int Cost, boolean Owned, int VisitCost){
        getImage().scale(100,100);
        this.cost=Cost;
        this.level=Level;
        this.owned=Owned;
        if(owned==false){
            this.stopCost=0;
        }
        else{
            this.stopCost=VisitCost;
        }
    }
    
    public void act()
    {
        
    }
    
    public Actor playerPlace(){
        return getOneIntersectingObject(PLAYERS.class);
    }
    
    public void upgrade()
    {
        if(upgradeClicked && level<3 && money >= upgradeCost)
        {
            money-=upgradeCost;
            level++;
        }
    }
    
        public void buy()
    {
        World world1 = getWorld();
        Board myWorld = (Board) world1;
        int turn = myWorld.turn;
        if(buyClicked && money >= cost)
        {
            money-=cost;
            owned = true;
            ownedBy = activePlayer(turn);
        }
    }
    
    public int activePlayer(int turn)
    {
        if (turn == 1)
        {
            return 1;
        }
        if (turn == 2)
        {
            return 2;
        }
        if (turn == 3)
        {
            return 3;
        }
        if (turn == 4)
        {
            return 4;
        }
        else
        {
            return 0;
        }
    }
}