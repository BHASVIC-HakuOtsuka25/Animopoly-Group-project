import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GreenFish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GreenFish extends Animals
{
    /**
     * Act - do whatever the GreenFish wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public GreenFish(){
        super(0,400,false,40);
    }
    public void act()
    {
        // Add your action code here.
    }
}
