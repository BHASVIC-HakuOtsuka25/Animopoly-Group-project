import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Board extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    int turn;
    public Board()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(5, 5, 100); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Alligator alligator = new Alligator();
        addObject(alligator,0,0);
        Ant ant = new Ant();
        addObject(ant,1,0);
        Beetle beetle = new Beetle();
        addObject(beetle,2,0);
        BigAnt bigAnt = new BigAnt();
        addObject(bigAnt,3,0);
        Butterfly butterfly = new Butterfly();
        addObject(butterfly,4,0);
        Camel camel = new Camel();
        addObject(camel,4,1);
        Dolphin dolphin = new Dolphin();
        addObject(dolphin,4,2);
        Elephant elephant = new Elephant();
        addObject(elephant,4,3);
        Fish fish = new Fish();
        addObject(fish,4,4);
        Fly fly = new Fly();
        addObject(fly,3,4);
        Frog frog = new Frog();
        addObject(frog,2,4);
        GreenFish greenFish = new GreenFish();
        addObject(greenFish,1,4);
        Hedgehog hedgehog = new Hedgehog();
        addObject(hedgehog,0,4);
        Hippo hippo = new Hippo();
        addObject(hippo,0,3);
        Ugly ugly = new Ugly();
        addObject(ugly,0,2);
        Wasp wasp = new Wasp();
        addObject(wasp,0,1);

        PLAYER1 pLAYER1 = new PLAYER1();
        addObject(pLAYER1,0,0);
        
        PLAYER2 pLAYER2 = new PLAYER2();
        addObject(pLAYER2,0,0);
        
        PLAYER3 pLAYER3 = new PLAYER3();
        addObject(pLAYER3,0,0);
        
        PLAYER4 pLAYER4 = new PLAYER4();
        addObject(pLAYER4,0,0);
    }
}
