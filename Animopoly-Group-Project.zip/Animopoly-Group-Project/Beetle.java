import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Beetle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Beetle extends Animals
{
    /**
     * Act - do whatever the Beetle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Beetle(){
        super(0,300,false,30);
    }
    public void act()
    {
        // Add your action code here.
    }
}
