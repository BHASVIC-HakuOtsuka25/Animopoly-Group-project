import greenfoot.*;  
 
public class PLAYER4 extends PLAYERS
{
    public int ID = 4;
    private int timer = 0;
    private static final int TARGET = 60;
        public void act()
    {
        timer++;
        if (timer >= TARGET) {
        timer = 0;
        move();
    }
    }
}