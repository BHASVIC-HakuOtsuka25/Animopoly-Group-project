import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ugly here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ugly extends Animals
{
    /**
     * Act - do whatever the Ugly wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Ugly(){
        super(0,10000,false,1000);
    }
    public void act()
    {
        // Add your action code here.
    }
}
