import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Wasp here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Wasp extends Animals
{
    /**
     * Act - do whatever the Wasp wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Wasp(){
        super(0,650,false,65);
    }
    public void act()
    {
        // Add your action code here.
    }
}
