import greenfoot.*;
 
public class PLAYERS extends Actor
{
    int money = 2000;
    int playerCount = 4;
    boolean alive = true;
    int horizontalSpeed;
    int verticalSpeed;
    private int timer = 0;
    private static final int TARGET = 60;
    public PLAYERS(){
        getImage().scale(75,75);
    }
    public void act()
    {
        Money();
        Win();
        timer++;
    if (timer >= TARGET) {
        timer = 0;
        move();
    }
}
    public void Money()
    {
        if(money < 0)
        {
            alive = false;
        }
    }
    public boolean Win()
    {
        if(playerCount == 1 && alive == true){
            return true;
        }
        else
        {
            return false;
        }
    }   
    public void move()
        {
        
            setLocation(getX() + horizontalSpeed, getY() + verticalSpeed);
    
    if(getRotation() == 0){horizontalSpeed = dice();}
    if(getRotation() == 180){horizontalSpeed = (dice() * -1);}
    if(getRotation() == 90){verticalSpeed = dice();}
    if(getRotation() == 270){verticalSpeed = (dice() * -1);}
    
    if(getY() == 0){if(getX() == 0){setRotation(0);}}
    if(getY() == 0){if(getX() == 4){setRotation(90);}}
    if(getY() == 4){if(getX() == 4){setRotation(180);}}
    if(getY() == 4){if(getX() == 0){setRotation(270);}}
    
        }
    public int dice(){
        return((Greenfoot.getRandomNumber(3)+1) + (Greenfoot.getRandomNumber(3)+1));
    }
}
