import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BuyPopUp here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BuyPopUp extends Actor
{
    /**
     * Act - do whatever the BuyPopUp wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    Board board;
    String name="Buying";
    public BuyPopUp(){
        setImage(new GreenfootImage("Buying",30,Color.BLACK,Color.WHITE));
    }
    public void act()
    {
        setImage(new GreenfootImage("Buying",30,Color.BLACK,Color.WHITE));
    }
}
