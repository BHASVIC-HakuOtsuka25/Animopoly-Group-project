import greenfoot.*;  
 
public class PLAYER2 extends PLAYERS
{
    public int ID = 2;
    private int timer = 0;
    private static final int TARGET = 60;
        public void act()
    {
        timer++;
        if (timer >= TARGET) {
        timer = 0;
        move();
    }
    }
}
